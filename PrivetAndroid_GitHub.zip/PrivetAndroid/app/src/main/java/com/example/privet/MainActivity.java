package com.example.privet;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        TextView text = new TextView(this);
        text.setText("Привет!");
        text.setTextColor(Color.BLACK);
        text.setTextSize(32);
        text.setGravity(Gravity.CENTER);
        text.setBackgroundColor(Color.WHITE);
        setContentView(text);
    }
}
